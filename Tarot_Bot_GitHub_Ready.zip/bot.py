import os
import sqlite3, random, html
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
DB = os.getenv("DB_PATH", "tarot_bot_v3.db")

# 78 cards: 22 Major + 56 Minor
MAJOR=[
("The Fool","new beginnings, freedom, curiosity"),
("The Magician","skill, initiative, confidence"),
("The High Priestess","intuition, patience, hidden knowledge"),
("The Empress","growth, creativity, care, abundance"),
("The Emperor","structure, leadership, stability"),
("The Hierophant","learning, tradition, guidance"),
("The Lovers","connection, choices, values, partnership"),
("The Chariot","determination, direction, discipline"),
("Strength","courage, patience, compassion"),
("The Hermit","reflection, wisdom, inner guidance"),
("Wheel of Fortune","change, cycles, turning points"),
("Justice","balance, accountability, fairness"),
("The Hanged Man","pause, perspective, letting go"),
("Death","transformation, closure, transition"),
("Temperance","balance, moderation, harmony"),
("The Devil","attachment, temptation, unhealthy patterns"),
("The Tower","sudden change, truth, rebuilding"),
("The Star","hope, healing, inspiration"),
("The Moon","uncertainty, intuition, checking assumptions"),
("The Sun","joy, clarity, confidence"),
("Judgement","reflection, awakening, realization"),
("The World","completion, achievement, full cycle")]

RANKS=["Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Page","Knight","Queen","King"]
SUITS={
"Wands":"energy, ambition, creativity, action",
"Cups":"feelings, relationships, empathy, connection",
"Swords":"thoughts, communication, decisions, clarity",
"Pentacles":"money, work, study, stability, practical matters"}
CARDS=MAJOR+[(f"{r} of {s}",m) for s,m in SUITS.items() for r in RANKS]

T={
"my":{"welcome":"🔮 <b>Tarot Reading</b>\n\nကြိုဆိုပါတယ်။ အောက်က Menu ကနေ စတင်ပါ။","tarot":"🔮 Tarot ဖတ်မယ်","daily":"🌞 ဒီနေ့ကတ်","history":"📖 History","search":"🔎 Card ရှာမယ်","lang":"🌐 Language","admin":"👑 Admin","topic":"ဘာအကြောင်းအရာအတွက် ဖတ်မလဲ?","love":"❤️ Love","career":"💼 Career","money":"💰 Money","study":"📚 Study","general":"🌙 General","spread":"Reading ပုံစံရွေးပါ","one":"🃏 1 Card","three":"🃏🃏🃏 3 Cards","back":"⬅️ Back","home":"🏠 Main Menu","again":"🔄 ထပ်ဖတ်မယ်","question":"💬 မေးခွန်းထည့်မယ်","skip":"⏭️ မေးခွန်းမထည့်ဘဲ ဆက်မယ်","empty":"📖 History မရှိသေးပါ။","choose_lang":"🌐 ဘာသာစကားရွေးပါ","saved":"✅ Language ပြောင်းပြီးပါပြီ။","dis":"⚠️ Tarot သည် ဖျော်ဖြေရေး/ကိုယ်တိုင်ပြန်စဉ်းစားရန်အတွက်သာဖြစ်ပြီး အနာဂတ်ကို သေချာခန့်မှန်းပေးခြင်းမဟုတ်ပါ။"},
"en":{"welcome":"🔮 <b>Tarot Reading</b>\n\nWelcome. Choose an option below.","tarot":"🔮 Tarot Reading","daily":"🌞 Daily Tarot","history":"📖 History","search":"🔎 Find Card","lang":"🌐 Language","admin":"👑 Admin","topic":"What would you like your reading about?","love":"❤️ Love","career":"💼 Career","money":"💰 Money","study":"📚 Study","general":"🌙 General","spread":"Choose a reading type","one":"🃏 1 Card","three":"🃏🃏🃏 3 Cards","back":"⬅️ Back","home":"🏠 Main Menu","again":"🔄 Read Again","question":"💬 Add a question","skip":"⏭️ Continue without a question","empty":"📖 No history yet.","choose_lang":"🌐 Choose your language","saved":"✅ Language changed.","dis":"⚠️ Tarot is for entertainment and reflection, not a guaranteed prediction of the future."}}

def db():
    return sqlite3.connect(DB)

def init():
    c=db();q=c.cursor()
    q.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT,name TEXT,lang TEXT DEFAULT 'my',joined TEXT,last_seen TEXT)")
    q.execute("CREATE TABLE IF NOT EXISTS readings(id INTEGER PRIMARY KEY AUTOINCREMENT,user INTEGER,topic TEXT,spread TEXT,result TEXT,created TEXT)")
    q.execute("CREATE TABLE IF NOT EXISTS daily(user INTEGER,day TEXT,card TEXT,pos TEXT,PRIMARY KEY(user,day))")
    q.execute("CREATE TABLE IF NOT EXISTS custom(name TEXT PRIMARY KEY,meaning TEXT)")
    c.commit();c.close()

def reg(u):
    n=datetime.now().strftime("%Y-%m-%d %H:%M:%S");c=db()
    c.execute("""INSERT INTO users VALUES(?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET username=excluded.username,name=excluded.name,last_seen=excluded.last_seen""",
    (u.id,u.username or "",u.first_name or "","my",n,n));c.commit();c.close()

def lang(uid):
    c=db();r=c.execute("SELECT lang FROM users WHERE id=?",(uid,)).fetchone();c.close()
    return r[0] if r else "my"

def tr(uid,k): return T[lang(uid)].get(k,k)
def setlang(uid,x):
    c=db();c.execute("UPDATE users SET lang=? WHERE id=?",(x,uid));c.commit();c.close()

def cards():
    c=db();x=c.execute("SELECT name,meaning FROM custom").fetchall();c.close()
    return CARDS+x

def topic(uid,k):
    if lang(uid)=="en": return {"love":"❤️ Love","career":"💼 Career","money":"💰 Money","study":"📚 Study","general":"🌙 General"}[k]
    return {"love":"❤️ အချစ်ရေး","career":"💼 အလုပ်အကိုင်","money":"💰 ငွေကြေး","study":"📚 ပညာရေး","general":"🌙 အထွေထွေ"}[k]

def esc(x): return html.escape(str(x))

def card_slug(name):
    return name.lower().replace("'", "").replace(" ", "_").replace("/", "_")


RARITY = {
    "Major": "🌟 Legendary",
    "Minor": "✨ Arcana",
    "Custom": "🪄 Custom"
}


def card_rarity(name):
    return RARITY["Major"] if name in [x[0] for x in MAJOR] else RARITY["Minor"]


def image_path(name):
    # Optional local images: cards/the_sun.jpg, cards/the_moon.jpg, etc.
    from pathlib import Path
    p = Path("cards") / f"{card_slug(name)}.jpg"
    return str(p) if p.exists() else None


def long_result(uid, name, meaning, t, rev, question="", position=None):
    l = lang(uid)
    pos = "Reversed" if rev else "Upright"
    q = (question or "").strip()

    if l == "my":
        topic_names = {
            "love":"❤️ အချစ်ရေး", "career":"💼 အလုပ်အကိုင်",
            "money":"💰 ငွေကြေး", "study":"📚 ပညာရေး",
            "general":"🌙 အထွေထွေ"
        }
        pos_name = "🔄 Reversed" if rev else "⬆️ Upright"
        core = ("ဒီကတ်ရဲ့ အဓိပ္ပါယ်ဟာ လက်ရှိအခြေအနေမှာ တစ်ခုခုကို ပြန်လည်စဉ်းစားဖို့၊ "
                "အရှိန်လျှော့ဖို့ သို့မဟုတ် နည်းလမ်းပြောင်းဖို့ သတိပေးနေသလို ဖတ်နိုင်ပါတယ်။"
                if rev else
                "ဒီကတ်က လက်ရှိအခြေအနေမှာ အဓိကထားသင့်တဲ့ energy နဲ့ သဘောထားကို ပြနေပါတယ်။")
        advice = {
            "love":"ခံစားချက်ကို တစ်ဖက်တည်းက ခန့်မှန်းမနေဘဲ ရိုးရိုးရှင်းရှင်း ဆက်သွယ်ပြောဆိုပြီး ကိုယ့်နယ်နိမိတ်ကိုလည်း ထိန်းထားပါ။",
            "career":"ဦးစားပေးရမယ့်အရာကို သတ်မှတ်ပြီး လက်တွေ့လုပ်ဆောင်နိုင်တဲ့ အဆင့်သေးသေးတွေခွဲလုပ်ပါ။",
            "money":"ငွေကြေးဆုံးဖြတ်ချက်တွေမှာ အချက်အလက်ကိုစစ်ပြီး ခဏတာအကျိုးထက် ရေရှည်အကျိုးဆက်ကိုပါ စဉ်းစားပါ။",
            "study":"တစ်ခါတည်းအများကြီးလုပ်မယ့်အစား နားလည်မှုကိုစစ်ပြီး တစ်ဆင့်ချင်း တိုးတက်အောင်လုပ်ပါ။",
            "general":"ဒီကတ်ကို အနာဂတ်အတည်ပြုချက်အဖြစ်မယူဘဲ ကိုယ့်အခြေအနေကို ပြန်ကြည့်ဖို့ reflection prompt တစ်ခုအဖြစ် အသုံးပြုပါ။"
        }[t]
        challenge = {
            "love":"အဓိက challenge က မပြောဖြစ်သေးတဲ့ခံစားချက်၊ မျှော်လင့်ချက်၊ ဒါမှမဟုတ် boundary တစ်ခု ဖြစ်နိုင်ပါတယ်။",
            "career":"အဓိက challenge က direction မရှင်းခြင်း၊ အလွန်အကျွံတာဝန်ယူခြင်း သို့မဟုတ် အချိန်မခွဲတတ်ခြင်း ဖြစ်နိုင်ပါတယ်။",
            "money":"အဓိက challenge က ချက်ချင်းဆုံးဖြတ်ချင်ခြင်း သို့မဟုတ် အချက်အလက်မပြည့်စုံသေးခြင်း ဖြစ်နိုင်ပါတယ်။",
            "study":"အဓိက challenge က consistency ပျက်ခြင်း သို့မဟုတ် အကြောင်းအရာများလွန်းလို့ အာရုံစူးစိုက်မှုလျော့ခြင်း ဖြစ်နိုင်ပါတယ်။",
            "general":"အဓိက challenge က ကိုယ့်ယူဆချက်နဲ့ အမှန်တကယ်ဖြစ်နေတဲ့အရာကို ခွဲကြည့်ဖို့ ဖြစ်ပါတယ်။"
        }[t]
        hidden = ("နောက်ကွယ်က message အနေနဲ့ အရာအားလုံးကို ချက်ချင်းဖြေရှင်းဖို့ မလိုပါဘူး။ "
                  "တစ်ဆင့်ချင်း သတိထားပြီး ရွေးချယ်တာက ပိုအရေးကြီးပါတယ်။")
        qpart = f"💬 <b>သင့်မေးခွန်း:</b> {esc(q)}\n\n" if q else ""
        return (
            f"🃏 <b>{esc(name)}</b>  •  {card_rarity(name)}\n"
            f"📍 <b>{esc(pos_name)}</b>\n"
            f"🎯 <b>{esc(topic_names[t])}</b>\n\n"
            f"{qpart}"
            f"✨ <b>ကတ်ရဲ့ အဓိကအဓိပ္ပါယ်</b>\n{esc(meaning)}\n\n"
            f"🔎 <b>သင့်အခြေအနေနဲ့ ချိတ်ဆက်ဖတ်ခြင်း</b>\n{esc(core)}\n\n"
            f"⚠️ <b>သတိထားရမယ့်အချက်</b>\n{esc(challenge)}\n\n"
            f"🧭 <b>လုပ်ဆောင်ချက်အကြံပြုချက်</b>\n{esc(advice)}\n\n"
            f"🌙 <b>Hidden Message</b>\n{esc(hidden)}"
        )

    # English
    topic_names = {"love":"❤️ Love","career":"💼 Career","money":"💰 Money","study":"📚 Study","general":"🌙 General"}
    core = ("This reversed position can suggest a blocked, delayed, or misunderstood expression of the card."
            if rev else
            "This upright position highlights the card's main energy and what may deserve attention now.")
    advice = {
        "love":"Communicate clearly, respect boundaries, and avoid assuming what another person feels.",
        "career":"Clarify priorities and break the next step into something practical and manageable.",
        "money":"Check the facts and consider longer-term effects before making a financial decision.",
        "study":"Focus on consistency, active review, and one manageable learning step at a time.",
        "general":"Use the card as a reflection prompt rather than a guaranteed statement about the future."
    }[t]
    challenge = {
        "love":"The challenge may involve unspoken feelings, expectations, or unclear boundaries.",
        "career":"The challenge may involve unclear direction, competing priorities, or overcommitment.",
        "money":"The challenge may be acting too quickly or deciding without enough information.",
        "study":"The challenge may be inconsistency, distraction, or trying to handle too much at once.",
        "general":"The challenge is separating assumptions from what you can actually observe and verify."
    }[t]
    hidden = "A useful hidden message is that you do not have to solve everything at once; a thoughtful next step can be enough."
    qpart = f"💬 <b>Your question:</b> {esc(q)}\n\n" if q else ""
    return (
        f"🃏 <b>{esc(name)}</b> • {card_rarity(name)}\n"
        f"📍 <b>{'🔄 Reversed' if rev else '⬆️ Upright'}</b>\n"
        f"🎯 <b>{esc(topic_names[t])}</b>\n\n"
        f"{qpart}"
        f"✨ <b>Core meaning</b>\n{esc(meaning)}\n\n"
        f"🔎 <b>Personal interpretation</b>\n{esc(core)}\n\n"
        f"⚠️ <b>Potential challenge</b>\n{esc(challenge)}\n\n"
        f"🧭 <b>Practical guidance</b>\n{esc(advice)}\n\n"
        f"🌙 <b>Hidden message</b>\n{esc(hidden)}"
    )


def combination_reading(uid, chosen, flags, t, question=""):
    l = lang(uid)
    names = [c[0] for c in chosen]
    if l == "my":
        q = f"\n💬 <b>မေးခွန်း:</b> {esc(question)}\n" if question else ""
        return (
            f"🔗 <b>🃏 Card Combination</b>{q}\n\n"
            f"ဒီ ၃ ကတ်ကို တစ်ခုချင်းစီအပြင် အစုလိုက်ဖတ်ရင် "
            f"အတိတ်က {esc(names[0])} က လက်ရှိ {esc(names[1])} ကို သက်ရောက်စေပြီး၊ "
            f"လက်ရှိအခြေအနေက နောက်တစ်ဆင့် {esc(names[2])} ကို ဘယ်လိုရောက်သွားနိုင်မလဲဆိုတာ "
            f"reflection အနေနဲ့ ကြည့်နိုင်ပါတယ်။\n\n"
            f"🧩 <b>Overall pattern</b>\n"
            f"အတိတ်မှာ ဖြစ်ခဲ့တဲ့ theme ကို နားလည်ပြီး၊ ပစ္စုပ္ပန်မှာ ဘာကိုရွေးချယ်မလဲဆိုတာ "
            f"သတိထားရင် အနာဂတ်ကို ပုံသေဟောကိန်းမဟုတ်ဘဲ ကိုယ့်ရွေးချယ်မှုတွေကနေ ဖန်တီးနိုင်တဲ့ "
            f"လမ်းကြောင်းတစ်ခုအဖြစ် မြင်နိုင်ပါတယ်။"
        )
    q = f"\n💬 <b>Question:</b> {esc(question)}\n" if question else ""
    return (
        f"🔗 <b>🃏 Card Combination</b>{q}\n\n"
        f"Read together, {esc(names[0])} can represent the past context, "
        f"{esc(names[1])} the current focus, and {esc(names[2])} a possible direction. "
        f"This is a reflective framework, not a fixed prediction.\n\n"
        f"🧩 <b>Overall pattern</b>\n"
        f"Notice how the themes connect and which practical choices are available to you now."
    )

def home(uid):
    rows=[[InlineKeyboardButton(tr(uid,"tarot"),callback_data="tarot")],
          [InlineKeyboardButton(tr(uid,"daily"),callback_data="daily"),InlineKeyboardButton(tr(uid,"history"),callback_data="history")],
          [InlineKeyboardButton(tr(uid,"search"),callback_data="search"),InlineKeyboardButton(tr(uid,"lang"),callback_data="language")]]
    if uid==ADMIN_ID: rows.append([InlineKeyboardButton(tr(uid,"admin"),callback_data="admin")])
    return InlineKeyboardMarkup(rows)

async def start(update,context):
    reg(update.effective_user);u=update.effective_user.id
    await update.message.reply_text(tr(u,"welcome"),parse_mode=ParseMode.HTML,reply_markup=home(u))

async def language_menu(update,context):
    q=update.callback_query;await q.answer();u=q.from_user.id
    await q.edit_message_text(tr(u,"choose_lang"),reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("🇲🇲 မြန်မာ",callback_data="lm"),InlineKeyboardButton("🇬🇧 English",callback_data="le")],
        [InlineKeyboardButton(tr(u,"back"),callback_data="home")]]))

async def language_change(update,context):
    q=update.callback_query;setlang(q.from_user.id,"my" if q.data=="lm" else "en");await q.answer(tr(q.from_user.id,"saved"))
    await q.edit_message_text(tr(q.from_user.id,"welcome"),parse_mode=ParseMode.HTML,reply_markup=home(q.from_user.id))

async def tarot(update,context):
    q=update.callback_query;await q.answer();u=q.from_user.id
    await q.edit_message_text(tr(u,"topic"),reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton(tr(u,"love"),callback_data="t_love"),InlineKeyboardButton(tr(u,"career"),callback_data="t_career")],
        [InlineKeyboardButton(tr(u,"money"),callback_data="t_money"),InlineKeyboardButton(tr(u,"study"),callback_data="t_study")],
        [InlineKeyboardButton(tr(u,"general"),callback_data="t_general")],
        [InlineKeyboardButton(tr(u,"back"),callback_data="home")]]))

async def choose_spread(update,context):
    q=update.callback_query;await q.answer();t=q.data[2:]
    context.user_data["topic"]=t;context.user_data["awaiting_question"]=False
    u=q.from_user.id
    await q.edit_message_text(
        f"{topic(u,t)}\n\n💬 {tr(u,'question')}?",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✍️ Question",callback_data="askq"),
             InlineKeyboardButton(tr(u,"skip"),callback_data="skipq")],
            [InlineKeyboardButton(tr(u,"back"),callback_data="tarot")]
        ])
    )


async def ask_question(update,context):
    q=update.callback_query;await q.answer()
    context.user_data["awaiting_question"]=True
    u=q.from_user.id
    msg = "💬 သင့်မေးခွန်းကို စာသားနဲ့ပို့ပါ။\nဥပမာ — ဒီအခြေအနေမှာ ဘာကိုပိုအာရုံစိုက်သင့်လဲ?" if lang(u)=="my" else \
          "💬 Send your question as text.\nExample — What should I focus on in this situation?"
    await q.edit_message_text(msg,reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton(tr(u,"back"),callback_data="tarot")]
    ]))


async def skip_question(update,context):
    q=update.callback_query;await q.answer()
    context.user_data["question"]=""
    context.user_data["awaiting_question"]=False
    u=q.from_user.id
    await q.edit_message_text(f"{topic(u,context.user_data.get('topic','general'))}\n\n{tr(u,'spread')}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(tr(u,"one"),callback_data="s1")],
            [InlineKeyboardButton(tr(u,"three"),callback_data="s3")],
            [InlineKeyboardButton(tr(u,"back"),callback_data="tarot")]
        ]))


async def save_question(update,context):
    if not context.user_data.get("awaiting_question"):
        return
    q=update.message.text.strip()
    if len(q)>500:
        q=q[:500]
    context.user_data["question"]=q
    context.user_data["awaiting_question"]=False
    u=update.effective_user.id
    await update.message.reply_text(
        ("✅ မေးခွန်းသိမ်းပြီးပါပြီ။ Reading ပုံစံရွေးပါ။" if lang(u)=="my" else "✅ Question saved. Choose your reading type."),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(tr(u,"one"),callback_data="s1")],
            [InlineKeyboardButton(tr(u,"three"),callback_data="s3")]
        ])
    )

async def send_card_image(update, context, name):
    path=image_path(name)
    if not path:
        return False
    try:
        await update.callback_query.message.reply_photo(photo=open(path,"rb"),caption=f"🃏 {name}")
        return True
    except Exception:
        return False


async def draw(update,context):
    q=update.callback_query;await q.answer();u=q.from_user.id
    t=context.user_data.get("topic","general")
    question=context.user_data.get("question","")
    n=1 if q.data=="s1" else 3
    chosen=random.sample(cards(),n); flags=[random.random()<.25 for _ in chosen]

    context.user_data["last_n"]=n
    context.user_data["last_cards"]=chosen
    context.user_data["last_flags"]=flags

    if n==1:
        out=long_result(u,*chosen[0],t,flags[0],question)
        save=" | ".join(f"{chosen[0][0]} ({'Reversed' if flags[0] else 'Upright'})")
        buttons=[[InlineKeyboardButton(tr(u,"again"),callback_data="again")],
                 [InlineKeyboardButton(tr(u,"history"),callback_data="history"),InlineKeyboardButton(tr(u,"home"),callback_data="home")]]
    else:
        ps=["🕰️ အတိတ်","🌅 ပစ္စုပ္ပန်","🔮 အနာဂတ်"] if lang(u)=="my" else ["🕰️ Past","🌅 Present","🔮 Future"]
        out="\n\n".join(
            f"<b>{p}</b>\n🃏 <b>{esc(c[0])}</b> • {card_rarity(c[0])} • {'🔄 Reversed' if r else '⬆️ Upright'}"
            for p,c,r in zip(ps,chosen,flags)
        )
        save=" | ".join(f"{c[0]} ({'Reversed' if r else 'Upright'})" for c,r in zip(chosen,flags))
        buttons=[
            [InlineKeyboardButton("🕰️ အတိတ်" if lang(u)=="my" else "🕰️ Past",callback_data="deep_past"),
             InlineKeyboardButton("🌅 ပစ္စုပ္ပန်" if lang(u)=="my" else "🌅 Present",callback_data="deep_present")],
            [InlineKeyboardButton("🔮 အနာဂတ်" if lang(u)=="my" else "🔮 Future",callback_data="deep_future"),
             InlineKeyboardButton("📜 အားလုံးဖတ်မယ်" if lang(u)=="my" else "📜 Read All",callback_data="deep_all")],
            [InlineKeyboardButton(tr(u,"again"),callback_data="again")],
            [InlineKeyboardButton(tr(u,"history"),callback_data="history"),InlineKeyboardButton(tr(u,"home"),callback_data="home")]
        ]

    c=db()
    c.execute("INSERT INTO readings(user,topic,spread,result,created) VALUES(?,?,?,?,?)",
              (u,t,f"{n}-card",save,datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    c.commit();c.close()

    await q.edit_message_text(
        f"🔮 <b>{topic(u,t)}</b>\n\n{out}\n\n{tr(u,'dis')}",
        parse_mode=ParseMode.HTML,reply_markup=InlineKeyboardMarkup(buttons)
    )


async def deep_read(update,context,index):
    q=update.callback_query;await q.answer();u=q.from_user.id
    chosen=context.user_data.get("last_cards",[])
    flags=context.user_data.get("last_flags",[])
    t=context.user_data.get("topic","general");question=context.user_data.get("question","")
    if len(chosen)!=3 or len(flags)!=3:
        await q.edit_message_text("❌ Reading session expired. Please start again.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(tr(u,"home"),callback_data="home")]]))
        return
    names=["🕰️ အတိတ်","🌅 ပစ္စုပ္ပန်","🔮 အနာဂတ်"] if lang(u)=="my" else ["🕰️ Past","🌅 Present","🔮 Future"]
    c=chosen[index]
    out=long_result(u,*c,t,flags[index],question,names[index])
    await q.edit_message_text(
        f"{names[index]}\n\n{out}\n\n{tr(u,'dis')}",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 📜 All 3 Cards",callback_data="deep_all")],
            [InlineKeyboardButton(tr(u,"again"),callback_data="again"),
             InlineKeyboardButton(tr(u,"home"),callback_data="home")]
        ])
    )


async def deep_all(update,context):
    q=update.callback_query;await q.answer();u=q.from_user.id
    chosen=context.user_data.get("last_cards",[]);flags=context.user_data.get("last_flags",[])
    t=context.user_data.get("topic","general");question=context.user_data.get("question","")
    if len(chosen)!=3:
        await q.edit_message_text("❌ Reading session expired.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(tr(u,"home"),callback_data="home")]]))
        return
    labels=["🕰️ အတိတ်","🌅 ပစ္စုပ္ပန်","🔮 အနာဂတ်"] if lang(u)=="my" else ["🕰️ Past","🌅 Present","🔮 Future"]
    parts=[f"<b>{labels[i]}</b>\n{long_result(u,*chosen[i],t,flags[i],question,labels[i])}" for i in range(3)]
    out="\n\n══════════════\n\n".join(parts)
    out += "\n\n══════════════\n\n" + combination_reading(u,chosen,flags,t,question)
    await q.edit_message_text(
        out[:3900] + f"\n\n{tr(u,'dis')}",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(tr(u,"again"),callback_data="again")],
            [InlineKeyboardButton(tr(u,"home"),callback_data="home")]
        ])
    )

async def again(update,context):
    q=update.callback_query;q.data="s1" if context.user_data.get("last_n",1)==1 else "s3";await draw(update,context)

async def daily(update,context):
    q=update.callback_query;await q.answer();u=q.from_user.id;day=datetime.now().strftime("%Y-%m-%d");c=db()
    r=c.execute("SELECT card,pos FROM daily WHERE user=? AND day=?",(u,day)).fetchone()
    if r:
        name,pos=r;card=next((x for x in cards() if x[0].lower()==name.lower()),random.choice(cards()));rev=pos=="Reversed"
    else:
        card=random.choice(cards());rev=random.random()<.25;c.execute("INSERT INTO daily VALUES(?,?,?,?)",(u,day,card[0],"Reversed" if rev else "Upright"));c.commit()
    c.close()
    await q.edit_message_text(f"🌞 <b>{tr(u,'daily')}</b>\n\n{result(u,*card,'general',rev)}\n\n{tr(u,'dis')}",parse_mode=ParseMode.HTML,reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(tr(u,"home"),callback_data="home")]]))

async def history(update,context):
    q=update.callback_query;await q.answer();u=q.from_user.id;c=db()
    rows=c.execute("SELECT topic,spread,result,created FROM readings WHERE user=? ORDER BY id DESC LIMIT 10",(u,)).fetchall();c.close()
    if not rows: out=tr(u,"empty")
    else:
        out="📖 <b>History</b>\n\n"+"\n\n".join(f"<b>{i}. {esc(topic(u,a))}</b> — {b}\n🃏 {esc(c)}\n📅 {d}" for i,(a,b,c,d) in enumerate(rows,1))
    await q.edit_message_text(out[:3900],parse_mode=ParseMode.HTML,reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(tr(u,"home"),callback_data="home")]]))

async def card_cmd(update,context):
    reg(update.effective_user);u=update.effective_user.id;s=" ".join(context.args).strip()
    if not s: await update.message.reply_text("/card The Sun");return
    m=[x for x in cards() if s.lower() in x[0].lower()]
    await update.message.reply_text("❌ Not found." if not m else "\n\n".join(f"🃏 <b>{esc(a)}</b>\n✨ {esc(b)}" for a,b in m[:8]),parse_mode=ParseMode.HTML)

async def admin(update,context):
    q=update.callback_query;await q.answer()
    if q.from_user.id!=ADMIN_ID:return
    await q.edit_message_text("👑 <b>Admin Panel</b>",parse_mode=ParseMode.HTML,reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Statistics",callback_data="stats")],[InlineKeyboardButton("🃏 Card Manager",callback_data="cm")],
        [InlineKeyboardButton(tr(q.from_user.id,"home"),callback_data="home")]]))

async def stats(update,context):
    q=update.callback_query;await q.answer()
    if q.from_user.id!=ADMIN_ID:return
    c=db();cur=c.cursor();total=cur.execute("SELECT COUNT(*) FROM users").fetchone()[0];reads=cur.execute("SELECT COUNT(*) FROM readings").fetchone()[0]
    day=datetime.now().strftime("%Y-%m-%d");new=cur.execute("SELECT COUNT(*) FROM users WHERE joined LIKE ?",(day+"%",)).fetchone()[0];active=cur.execute("SELECT COUNT(*) FROM users WHERE last_seen LIKE ?",(day+"%",)).fetchone()[0];custom=cur.execute("SELECT COUNT(*) FROM custom").fetchone()[0];c.close()
    await q.edit_message_text(f"📊 <b>Statistics</b>\n\n👥 Users: <b>{total}</b>\n🆕 New today: <b>{new}</b>\n🟢 Active today: <b>{active}</b>\n🔮 Readings: <b>{reads}</b>\n🃏 Cards: <b>{len(CARDS)+custom}</b>\n➕ Custom: <b>{custom}</b>",parse_mode=ParseMode.HTML,reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Admin",callback_data="admin")]]))

async def card_manager(update,context):
    q=update.callback_query;await q.answer()
    if q.from_user.id!=ADMIN_ID:return
    await q.edit_message_text("🃏 <b>Card Manager</b>\n\n/addcard Name | Meaning\n/delcard Name\n/cards",parse_mode=ParseMode.HTML,reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Admin",callback_data="admin")]]))

async def addcard(update,context):
    if update.effective_user.id!=ADMIN_ID:return
    p=update.message.text.partition(" ")[2].split("|",1)
    if len(p)!=2: await update.message.reply_text("/addcard Name | Meaning");return
    c=db();c.execute("INSERT OR REPLACE INTO custom VALUES(?,?)",(p[0].strip(),p[1].strip()));c.commit();c.close();await update.message.reply_text("✅ Card saved.")

async def delcard(update,context):
    if update.effective_user.id!=ADMIN_ID:return
    n=update.message.text.partition(" ")[2].strip();c=db();x=c.execute("DELETE FROM custom WHERE lower(name)=lower(?)",(n,));c.commit();c.close();await update.message.reply_text("✅ Deleted." if x.rowcount else "❌ Not found.")

async def cards_cmd(update,context):
    if update.effective_user.id!=ADMIN_ID:return
    c=db();r=c.execute("SELECT name,meaning FROM custom").fetchall();c.close();await update.message.reply_text("No custom cards." if not r else "\n\n".join(f"🃏 {esc(a)}\n{esc(b)}" for a,b in r),parse_mode=ParseMode.HTML)

async def cb(update,context):
    q=update.callback_query;d=q.data
    if d=="home":
        await q.answer();await q.edit_message_text(tr(q.from_user.id,"welcome"),parse_mode=ParseMode.HTML,reply_markup=home(q.from_user.id))
    elif d=="language": await language_menu(update,context)
    elif d in ("lm","le"): await language_change(update,context)
    elif d=="tarot": await tarot(update,context)
    elif d.startswith("t_"): await choose_spread(update,context)
    elif d in ("s1","s3"): await draw(update,context)
    elif d=="askq": await ask_question(update,context)
    elif d=="skipq": await skip_question(update,context)
    elif d=="deep_past": await deep_read(update,context,0)
    elif d=="deep_present": await deep_read(update,context,1)
    elif d=="deep_future": await deep_read(update,context,2)
    elif d=="deep_all": await deep_all(update,context)
    elif d=="again": await again(update,context)
    elif d=="daily": await daily(update,context)
    elif d=="history": await history(update,context)
    elif d=="search":
        await q.answer();await q.edit_message_text("🔎 /card The Sun",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(tr(q.from_user.id,"home"),callback_data="home")]]))
    elif d=="admin": await admin(update,context)
    elif d=="stats": await stats(update,context)
    elif d=="cm": await card_manager(update,context)

async def text_router(update,context):
    if context.user_data.get("awaiting_question"):
        await save_question(update,context)


def main():
    init()
    if not BOT_TOKEN: raise ValueError("BOT_TOKEN environment variable မတွေ့ပါ။")
    if not ADMIN_ID: raise ValueError("ADMIN_ID environment variable မတွေ့ပါ။")
    app=Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CommandHandler("card",card_cmd))
    app.add_handler(CommandHandler("addcard",addcard))
    app.add_handler(CommandHandler("delcard",delcard))
    app.add_handler(CommandHandler("cards",cards_cmd))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_router))
    app.add_handler(CallbackQueryHandler(cb))
    print("Tarot Bot V4 running...")
    app.run_polling()

if __name__=="__main__": main()
