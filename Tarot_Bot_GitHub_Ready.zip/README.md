# Tarot Bot V4

Telegram Tarot bot based on the V4 feature set.

## Features
- Myanmar / English
- 78 Tarot cards
- Love / Career / Money / Study / General topics
- 1-card and 3-card readings
- Upright / Reversed
- Long/deep reading
- User question input
- Past / Present / Future 3-card reading
- Individual deep-reading buttons
- All-cards combination reading
- Daily Tarot
- Reading history
- Card search
- Admin card management
- SQLite storage

## Environment Variables

Set these in your hosting service:

- `BOT_TOKEN` = Telegram BotFather token
- `ADMIN_ID` = your Telegram numeric user ID
- `DB_PATH` = optional database path (default: `tarot_bot_v3.db`)

## Run

```bash
pip install -r requirements.txt
python bot.py
```

Do not put your Telegram bot token directly in `bot.py` or commit it to GitHub.
